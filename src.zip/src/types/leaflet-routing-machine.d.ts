declare namespace L {
    namespace Routing {
      function control(options: any): any;
    }
  }
  